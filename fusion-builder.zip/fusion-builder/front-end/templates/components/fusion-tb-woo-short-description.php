<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.2
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_short_description-shortcode">
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{output}}}
	</div>
</script>
