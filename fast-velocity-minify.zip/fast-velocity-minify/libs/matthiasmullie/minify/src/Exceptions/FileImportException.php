<?php

/**
 * File Import Exception.
 *
 * Please report bugs on https://github.com/matthiasmullie/minify/issues
 *
 * @author Matthias Mullie <minify@mullie.eu>
 * @copyright Copyright (c) 2012, Matthias Mullie. All rights reserved
 * @license MIT License
 */

namespace FVM\MatthiasMullie\Minify\Exceptions;

/**
 * File Import Exception Class.
 *
 * @author Matthias Mullie <minify@mullie.eu>
 */
class FileImportException extends BasicException
{
}
