/**
 * Add collapseable boxes to our editor screens.
 */
postboxes.add_postbox_toggles(pagenow);

/**
 * The rest of our customizations.
 */
(function($) {

	$('#cptui_select_post_type_submit').hide();
	$('#cptui_select_taxonomy_submit').hide();

	if ($('#name').prop('readonly')) {
		// Store our original slug on page load for edit checking.
		var original_slug = $('#name').val();
	}

	// Track the last auto-filled label values so we only overwrite our own output.
	var autoFilledSingular = '';
	var autoFilledPlural = '';
	var lastAutoFilledSlug = '';
	var $singularLabel = $('#singular_label');
	var $pluralLabel = $('#label');
	var slugCheckTimer = null;
	var slugCheckXhr = null;

	function updateSaveButtons() {
		var hasError = !$('#slugexists').hasClass('hidemessage');
		$('input[name="cpt_submit"]').prop('disabled', hasError);
		$('#the7-rename-slug').prop('disabled', hasError);
	}

	$('#slugexists .slugexists-text').each(function() {
		$(this).data('default', $(this).text());
	});

	// Switch to newly selected post type or taxonomy automatically.
	$('#post_type').on('change',function(){
		$('#cptui_select_post_type').submit();
	});

	$('#taxonomy').on('change',function(){
		$( '#cptui_select_taxonomy' ).submit();
	});

	// Confirm our deletions
	$('.the7-delete-top, .the7-delete-bottom').on('click',function(e) {
		e.preventDefault();
		var msg = '';
		if (typeof the7_type_data !== 'undefined') {
			msg = the7_type_data.confirm;
		} else if (typeof the7_tax_data !== 'undefined') {
			msg = the7_tax_data.confirm;
		}
		var submit_delete_warning = $('<div class="the7-submit-delete-dialog">' + msg + '</div>').appendTo('#poststuff').dialog({
			'dialogClass'   : 'wp-dialog',
			'modal'         : true,
			'autoOpen'      : true,
			'buttons'       : {
				"OK": function() {
					var form = $(e.target).closest('form');
					$(e.target).off('click').click();
				},
				"Cancel": function() {
					$(this).dialog('close');
				}
			}
		});
	});

	// Rename slug flow.
	var $renameBtn = $('#the7-rename-slug');
	if ($renameBtn.length) {
		var renameActive = false;
		var $slugInput = $('#name');
		var savedSlug = $slugInput.val();
		var $cancelBtn = $('#the7-rename-cancel');

		function exitRenameMode() {
			renameActive = false;
			$slugInput.val(savedSlug).prop('readonly', true);
			$renameBtn.text($renameBtn.data('rename-text')).attr('class', $renameBtn.data('rename-class'));
			$cancelBtn.hide();
			$('#slugexists').addClass('hidemessage');
			updateSaveButtons();
		}

		$renameBtn.on('click', function () {
			if (!renameActive) {
				// Enter rename mode.
				renameActive = true;
				savedSlug = $slugInput.val();
				$slugInput.prop('readonly', false).focus();
				$(this).text($(this).data('save-text')).attr('class', $(this).data('save-class'));
				$cancelBtn.show();
				} else {
				// Save click.
				if ($slugInput.val() === savedSlug) {
					// Slug unchanged — exit rename mode silently.
					exitRenameMode();
				} else {
					// Slug changed — show confirmation dialog.
					showRenameConfirmDialog();
				}
			}
		});

		$cancelBtn.on('click', function () {
			exitRenameMode();
		});

		function showRenameConfirmDialog() {
			var $dialog = $('<div class="the7-rename-confirm-dialog">' + the7_rename_data.confirm_backup + '</div>').appendTo('#poststuff');
			$dialog.dialog({
				'dialogClass': 'wp-dialog',
				'title': the7_rename_data.dialog_title,
				'modal': true,
				'autoOpen': true,
				'closeOnEscape': true,
				'width': 480,
				'buttons': [
					{
						text: the7_rename_data.confirm_button,
						'class': 'button button-primary',
						click: function () {
							$(this).dialog('close');
							var $form = $renameBtn.closest('form');
							// Append hidden submit field because programmatic .submit() does not include button values.
							$form.append('<input type="hidden" name="cpt_submit" value="1">');
							$form.off('submit.the7rename').submit();
						}
					},
					{
						text: the7_rename_data.cancel_button,
						'class': 'button button-secondary',
						click: function () {
							$(this).dialog('close');
						}
					}
				],
				'close': function () {
					$('body').css('overflow', '');
					$dialog.remove();
				},
				'open': function () {
					$(this).closest('.ui-dialog').find('.button-primary').trigger('focus');
					$('body').css('overflow', 'hidden');
				}
			});
		}

		// Intercept form submit when slug has been changed in rename mode.
		$renameBtn.closest('form').on('submit.the7rename', function (e) {
			if (renameActive && $slugInput.val() !== savedSlug) {
				e.preventDefault();
				showRenameConfirmDialog();
			}
		});
	}

	// Toggles help/support accordions.
	$('#support .question').each(function() {
		var tis = $(this), state = false, answer = tis.next('div').slideUp();
		tis.on('click keydown',function(e) {
			// Helps with accessibility and keyboard navigation.
			if(e.type==='keydown' && e.keyCode!==32 && e.keyCode!==13) {
				return;
			}
			e.preventDefault();
			state = !state;
			answer.slideToggle(state);
			tis.toggleClass('active',state);
			tis.attr('aria-expanded', state.toString() );
			tis.focus();
		});
	});

	// Switch spaces for underscores on our slug fields.
	$('#name').on('keyup',function(e){
		if ($(this).prop('readonly')) {
			return;
		}
		var value, original_value;
		value = original_value = $(this).val();
		if ( e.keyCode !== 9 && e.keyCode !== 37 && e.keyCode !== 38 && e.keyCode !== 39 && e.keyCode !== 40 ) {
			value = value.replace(/ /g, "_");
			value = value.toLowerCase();
			value = replaceDiacritics(value);
			value = transliterate(value);
			value = replaceSpecialCharacters(value);
			if ( value !== original_value ) {
				$(this).prop('value', value);
			}
		}

		var $slugexists = $('#slugexists');
		var slugTaken = false;
		if (typeof the7_type_data != 'undefined' && the7_type_data.existing_post_types.hasOwnProperty(value) && value !== original_slug) {
			slugTaken = true;
		}
		if (typeof the7_tax_data != 'undefined' && the7_tax_data.existing_taxonomies.hasOwnProperty(value) && value !== original_slug) {
			slugTaken = true;
		}
		$slugexists.toggleClass('hidemessage', !slugTaken);
		updateSaveButtons();

		// Cancel any pending AJAX slug check.
		if (slugCheckTimer) {
			clearTimeout(slugCheckTimer);
			slugCheckTimer = null;
		}
		if (slugCheckXhr) {
			slugCheckXhr.abort();
			slugCheckXhr = null;
		}

		// If local check already found a conflict, restore default text and skip AJAX.
		var $slugexistsText = $slugexists.find('.slugexists-text');
		if (slugTaken) {
			$slugexistsText.text($slugexistsText.data('default'));
		} else if (value && value !== original_slug && typeof the7_ajax_data !== 'undefined') {
			// Debounced AJAX check for page slug conflicts and reserved names.
			slugCheckTimer = setTimeout(function() {
				var checkType = the7_ajax_data.type || ((typeof the7_type_data !== 'undefined') ? 'post_type' : 'taxonomy');
				slugCheckXhr = $.ajax({
					url: the7_ajax_data.ajax_url,
					type: 'POST',
					data: {
						action: 'the7_check_slug',
						nonce: the7_ajax_data.nonce,
						slug: value,
						type: checkType,
						original_slug: original_slug || ''
					},
					success: function(response) {
						if ($('#name').val() !== value) return;
						if (response.success && response.data && !response.data.available) {
							$slugexistsText.text(response.data.message);
							$slugexists.removeClass('hidemessage');
							updateSaveButtons();
						}
					}
				});
			}, 500);
		}

		// Auto-fill singular and plural labels from slug.
		if (value === lastAutoFilledSlug) {
			return;
		}
		lastAutoFilledSlug = value;

		if (value) {
			var singular = slugToLabel(value);
			var plural = pluralize(singular);

			if ($singularLabel.val() === '' || $singularLabel.val() === autoFilledSingular) {
				$singularLabel.val(singular);
				autoFilledSingular = singular;
			}
			if ($pluralLabel.val() === '' || $pluralLabel.val() === autoFilledPlural) {
				$pluralLabel.val(plural);
				autoFilledPlural = plural;
			}
		} else {
			if ($singularLabel.val() === autoFilledSingular) {
				$singularLabel.val('');
				autoFilledSingular = '';
			}
			if ($pluralLabel.val() === autoFilledPlural) {
				$pluralLabel.val('');
				autoFilledPlural = '';
			}
		}
	});

	// Convert slug to title-cased singular label.
	function slugToLabel(slug) {
		return slug.replace(/[_-]/g, ' ').replace(/\b\w/g, function(c) {
			return c.toUpperCase();
		});
	}

	// Basic English pluralization of the last word.
	function pluralize(label) {
		var words = label.split(' ');
		var last = words[words.length - 1];
		var lower = last.toLowerCase();

		if (/(?:s|sh|ch|x|z)$/.test(lower)) {
			last = last + 'es';
		} else if (/[^aeiou]y$/i.test(lower)) {
			last = last.slice(0, -1) + (last[last.length - 1] === 'Y' ? 'Ies' : 'ies');
		} else {
			last = last + 's';
		}

		words[words.length - 1] = last;
		return words.join(' ');
	}

	// Replace diacritic characters with latin characters.
	function replaceDiacritics(s) {
		var diacritics = [
			/[\300-\306]/g, /[\340-\346]/g,  // A, a
			/[\310-\313]/g, /[\350-\353]/g,  // E, e
			/[\314-\317]/g, /[\354-\357]/g,  // I, i
			/[\322-\330]/g, /[\362-\370]/g,  // O, o
			/[\331-\334]/g, /[\371-\374]/g,  // U, u
			/[\321]/g, /[\361]/g, // N, n
			/[\307]/g, /[\347]/g  // C, c
		];

		var chars = ['A', 'a', 'E', 'e', 'I', 'i', 'O', 'o', 'U', 'u', 'N', 'n', 'C', 'c'];

		for (var i = 0; i < diacritics.length; i++) {
			s = s.replace(diacritics[i], chars[i]);
		}

		return s;
	}

	function replaceSpecialCharacters(s) {
		if ( 'cpt-ui_page_cptui_manage_post_types' === window.pagenow ) {
			s = s.replace(/[^a-z0-9\s-]/gi, '_');
		} else {
			s = s.replace(/[^a-z0-9\s]/gi, '_');
		}

		return s;
	}

	function composePreviewContent(value) {

		var re = /(http|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])?/;
		var is_url = re.test(value);

		if (!value) {
			return '';
		} else if (0 === value.indexOf('dashicons-')) {
			return $('<div class="dashicons-before"><br></div>').addClass(htmlEncode(value));
		} else if ( is_url ) {
			var imgsrc = encodeURI(value);
			var theimg = document.createElement('IMG');
			theimg.src = imgsrc;
			return theimg;
		}
	}

	function htmlEncode(str) {
		return String(str).replace(/[^-\w. ]/gi, function (c) {
			return '&#' + c.charCodeAt(0) + ';';
		});
	}

	var cyrillic = {
		"Ё": "YO", "Й": "I", "Ц": "TS", "У": "U", "К": "K", "Е": "E", "Н": "N", "Г": "G", "Ш": "SH", "Щ": "SCH", "З": "Z", "Х": "H", "Ъ": "'", "ё": "yo", "й": "i", "ц": "ts", "у": "u", "к": "k", "е": "e", "н": "n", "г": "g", "ш": "sh", "щ": "sch", "з": "z", "х": "h", "ъ": "'", "Ф": "F", "Ы": "I", "В": "V", "А": "a", "П": "P", "Р": "R", "О": "O", "Л": "L", "Д": "D", "Ж": "ZH", "Э": "E", "ф": "f", "ы": "i", "в": "v", "а": "a", "п": "p", "р": "r", "о": "o", "л": "l", "д": "d", "ж": "zh", "э": "e", "Я": "Ya", "Ч": "CH", "С": "S", "М": "M", "И": "I", "Т": "T", "Ь": "'", "Б": "B", "Ю": "YU", "я": "ya", "ч": "ch", "с": "s", "м": "m", "и": "i", "т": "t", "ь": "'", "б": "b", "ю": "yu"
	};

	function transliterate(word) {
		return word.split('').map(function (char) {
			return cyrillic[char] || char;
		}).join("");
	}

	if ( undefined != wp.media ) {
		var _custom_media = true,
			_orig_send_attachment = wp.media.editor.send.attachment;
	}

	$('#the7-choose-icon').on('click',function(e){
		e.preventDefault();

		var button = $(this);
		var id = jQuery('#menu_icon').attr('id');
		_custom_media = true;
		wp.media.editor.send.attachment = function (props, attachment) {
			if (_custom_media) {
				$("#" + id).val(attachment.url).change();
			} else {
				return _orig_send_attachment.apply(this, [props, attachment]);
			}
		};

		wp.media.editor.open(button);
		return false;
	});

	$('#menu_icon').on('change', function () {
		var value = $(this).val();
		value = value.trim();
		$('#the7-menu-icon-preview').html(composePreviewContent(value));
	});

	$('.the7-help').on('click',function(e){
		e.preventDefault();
	});

	$('.the7-taxonomy-submit').on('click',function(e){
		if ( $('.the7-table fieldset :checkbox:checked').length == 0 ) {
			e.preventDefault();
			var no_associated_type_warning = $('<div class="the7-taxonomy-empty-types-dialog">' + the7_tax_data.no_associated_type + '</div>').appendTo('#poststuff').dialog({
				'dialogClass'   : 'wp-dialog',
				'modal'         : true,
				'autoOpen'      : true,
				'buttons'       : {
					"OK": function() {
						$(this).dialog('close');
					}
				}
			});
		}
	});

	$('#auto-populate').on( 'click tap', function(e){
		e.preventDefault();

		var slug     = $('#name').val();
		var plural   = $('#label').val();
		var singular = $('#singular_label').val();
		var fields   = $('.the7-labels input[type="text"]');

		if ( '' === slug ) {
			return;
		}
		if ( '' === plural ) {
			plural = pluralize(slugToLabel(slug));
		}
		if ( '' === singular ) {
			singular = slugToLabel(slug);
		}

		$(fields).each( function( i, el ) {
			var newval = $( el ).data( 'label' );
			var plurality = $( el ).data( 'plurality' );
			if ( 'undefined' !== newval ) {
				// "slug" is our placeholder from the labels.
				if ( 'plural' === plurality ) {
					newval = newval.replace(/item/gi, plural);
				} else {
					newval = newval.replace(/item/gi, singular);
				}
				if ( $( el ).val() === '' ) {
					$(el).val(newval);
				}
			}
		} );
	});

	$('#auto-clear').on( 'click tap', function(e) {
		e.preventDefault();

		var fields = $('.the7-labels input[type="text"]');

		$(fields).each( function( i, el ) {
			$(el).val('');
		});
	});

})(jQuery);
