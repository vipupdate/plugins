<?php

namespace The7_Post_Types\Models;

use The7_Post_Types\Models\Items\Bundled_Taxonomy;
use The7_Post_Types\Models\Items\Taxonomy;

defined( 'ABSPATH' ) || exit;

class Taxonomies extends Composition_Model {

	/**
	 * @return string
	 */
	protected static function get_data_key() {
		return 'the7_core_taxonomies';
	}

	public static function update( $data ) {
		$result = parent::update( $data );

		if ( $result && ! empty( $data['name'] ) ) {
			delete_option( "default_term_{$data['name']}" );
		}

		return $result;
	}

	public static function delete( $slug ) {
		$result = parent::delete( $slug );

		if ( $result ) {
			delete_option( "default_term_{$slug}" );
		}

		return $result;
	}

	public static function convert( $original_slug, $new_slug ) {
		global $wpdb;

		$wpdb->update(
			$wpdb->term_taxonomy,
			[ 'taxonomy' => $new_slug ],
			[ 'taxonomy' => $original_slug ],
			[ '%s' ],
			[ '%s' ]
		);
	}

	/**
	 * @param $data
	 *
	 * @return Taxonomy
	 */
	protected static function create_custom_item( $data ) {
		return new Taxonomy( $data );
	}

	/**
	 * @param $data
	 * @param $class
	 *
	 * @return Bundled_Taxonomy
	 */
	protected static function create_bundled_item( $data, $class = null ) {
		return new Bundled_Taxonomy( $data, $class );
	}
}
