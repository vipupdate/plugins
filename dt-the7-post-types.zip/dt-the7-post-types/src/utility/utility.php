<?php

namespace The7_Post_Types\Utility;

defined( 'ABSPATH' ) || exit;

class Utility {

	public static function get_disp_boolean( $bool_text ) {
		$bool_text = (string) $bool_text;
		if ( empty( $bool_text ) || '0' === $bool_text || 'false' === $bool_text ) {
			return false;
		}

		return true;
	}

	public static function disp_boolean( $bool_text ) {
		$bool_text = (string) $bool_text;
		if ( empty( $bool_text ) || '0' === $bool_text || 'false' === $bool_text ) {
			return 'false';
		}

		return 'true';
	}

	public static function escape_label( string $label, string $default = '' ) {
		$label = substr( $label, 0, 256 );
		$label = sanitize_text_field( wp_strip_all_tags( $label ) );

		return $label ?: $default;
	}

}
