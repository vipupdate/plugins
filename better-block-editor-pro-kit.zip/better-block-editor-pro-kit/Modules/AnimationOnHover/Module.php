<?php
/**
 * Adds Animation on Hover settings to all blocks.
 *
 * @package BbeProKit
 */

namespace BbeProKit\Modules\AnimationOnHover;

use BetterBlockEditor\Base\ManagableModuleInterface;
use BbeProKit\Base\ModuleBasePro;
use BetterBlockEditor\Core\BlockUtils;

defined( 'ABSPATH' ) || exit;

class Module extends ModuleBasePro implements ManagableModuleInterface {


	const MODULE_IDENTIFIER = 'animation-on-hover';
	const ASSETS_BUILD_PATH = 'editor/blocks/__all__/animation-on-hover/';

	const SETTINGS_ORDER = 1100;

	const ATTRIBUTE_GROUP = 'wpbbeAnimationOnHover';

	const CSS_VAR_SETTINGS = array(
		'translateX' => array( 'var' => 'translate-x' ),
		'translateY' => array( 'var' => 'translate-y' ),
		'scale'      => array( 'var' => 'scale' ),
		'duration'   => array( 'var' => 'duration' ),
	);

	public function setup_hooks() {
		add_filter( 'render_block', array( $this, 'render' ), 20, 3 );
		add_filter( 'wpbbe_script_data', array( $this, 'add_script_data' ) );
	}

	public function add_script_data( $data ) {
		$data[ self::MODULE_IDENTIFIER ] = array(
			'cssVarSettings' => self::CSS_VAR_SETTINGS,
		);
		return $data;
	}

	public function render( $block_content, $block ) {
		if ( $block_content === '' ) {
			return $block_content;
		}

		$hover_settings = $block['attrs'][ self::ATTRIBUTE_GROUP ] ?? null;
		$hover_root     = ! empty( $block['attrs']['wpbbeAnimationOnHoverRoot'] );

		if ( null === $hover_settings && ! $hover_root ) {
			return $block_content;
		}

		$classes = array();

		if ( null !== $hover_settings ) {
			$tag = BlockUtils::get_tag_to_modify( $block_content );
			$tag->set_attribute( 'data-hover-animation', 'true' );

			if ( ! empty( $hover_settings['timingFunction'] ) ) {
				$tag->set_attribute( 'data-hover-easing', $hover_settings['timingFunction'] );
			}

			$block_content = $tag->get_updated_html();

			$class_id  = BlockUtils::get_unique_class_id( $block_content );
			$classes[] = $class_id;

			$vars = BlockUtils::generate_css_variables( self::CSS_VAR_SETTINGS, $hover_settings, '--wpbbe-transform-' );
			if ( $vars ) {
				BlockUtils::add_styles_from_css_rules(
					array(
						array(
							'selector'     => '.' . $class_id,
							'declarations' => $vars,
						),
					)
				);
			}
		}

		if ( $hover_root ) {
			$classes[] = 'wpbbe-hover-root';
		}

		return BlockUtils::append_classes( $block_content, $classes );
	}

	public static function get_title() {
		return __( 'Animation on Hover', 'better-block-editor' );
	}

	public static function get_label() {
		return __( 'Add Animation on Hover settings to all blocks.', 'better-block-editor' );
	}
}
