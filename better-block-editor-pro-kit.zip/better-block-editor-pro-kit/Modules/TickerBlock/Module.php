<?php
/**
 * Ticker block module.
 *
 * @package BbeProKit
 */

namespace BbeProKit\Modules\TickerBlock;

use BetterBlockEditor\Core\ResponsiveBlockUtils;
use BetterBlockEditor\Core\Settings;
use BetterBlockEditor\Core\BlockUtils;
use BbeProKit\Base\ModuleBasePro;
use BetterBlockEditor\Base\ManagableModuleInterface;

defined( 'ABSPATH' ) || exit;

class Module extends ModuleBasePro implements ManagableModuleInterface {

	const MODULE_IDENTIFIER = 'ticker_block';

	const ASSETS_BUILD_PATH = 'blocks/ticker';

	const SETTINGS_ORDER = 2000;

	const CSS_VAR_SETTINGS = array(
		'itemGap'            => array(
			'var'  => 'gap',
			'type' => 'spacing',
		),
		'animationSpeed'     => array(
			'var'  => 'animation-speed',
			'type' => 'custom',
		),
		'flexSize'           => array(
			'attr' => 'flexLayout.flexSize',
			'var'  => 'item-width',
			'type' => 'custom',
		),
		'flexMaxWidth'       => array(
			'attr' => 'flexLayout.maxWidth',
			'var'  => 'item-max-width',
			'type' => 'custom',
		),
		'justifyContent'     => array(
			'var'  => 'item-justify',
			'type' => 'justify',
		),
		'verticalAlignment'  => array(
			'var'  => 'item-alignment',
			'type' => 'string',
		),
		'maskImage'          => array(
			'var'  => 'mask-image',
			'type' => 'string',
		),
		'animationState'     => array(
			'var'  => 'animation-state',
			'type' => 'string',
		),
		'animationDirection' => array(
			'var'  => 'animation-direction',
			'type' => 'string',
		),
	);


	public function add_script_data( $data ) {
		$data[ static::MODULE_IDENTIFIER ] = array(
			'cssVarSettings' => self::CSS_VAR_SETTINGS,
		);

		return $data;
	}

	public function init() {
		parent::init();
		register_block_type(
			BBE_PRO_KIT_BLOCKS_DIR . 'ticker',
			array(
				'render_callback' => array( $this, 'render_ticker' ),
			)
		);
	}

	public function setup_hooks() {
		add_filter( 'wpbbe_script_data', array( $this, 'add_script_data' ) );
	}

	public static function get_tab() {
		return Settings::TAB_BLOCKS;
	}

	public static function get_title() {
		return __( 'BBE Ticker', 'better-block-editor' );
	}

	public static function get_label() {
		return __( 'Enable the BBE Ticker and its child blocks.', 'better-block-editor' );
	}

	/**
	 * {inheritdocs}
	 */
	public static function get_description() {
		return __( 'Display Ticker: BBE Ticker Content, BBE Ticker Item', 'better-block-editor' );
	}


	/**
	 * Render the ticker block.
	 *
	 * @param array  $attributes The block attributes.
	 * @param string $content    The block content.
	 *
	 * @return string The rendered block.
	 */
	public function render_ticker( $attributes, $content ) {
		$flex_layout  = $attributes['flexLayout'] ?? array();
		$self_stretch = $flex_layout['selfStretch'] ?? 'fit';

		$class_id     = BlockUtils::create_unique_class_id();
		$base_classes = array( 'wpbbe-ticker', $class_id );
		if ( $self_stretch !== 'fit' ) {
			$base_classes[] = 'is-stretch-' . $self_stretch;
		}

		$wrapper_classes = BlockUtils::append_block_wrapper_classes( $base_classes );

		$attributes_normalized = BlockUtils::normalize_attributes_for_css( self::CSS_VAR_SETTINGS, $attributes );
		$vars                  = BlockUtils::generate_css_variables( self::CSS_VAR_SETTINGS, $attributes_normalized, ' --wpbbe-ticker-' );
		if ( $vars ) {
			BlockUtils::add_styles_from_css_rules(
				array(
					array(
						'selector'     => '.' . $class_id,
						'declarations' => $vars,
					),
				)
			);
		}

		$switch_width = ResponsiveBlockUtils::get_switch_width( $attributes );
		if ( $switch_width ) {
			$attributes_responsive = ResponsiveBlockUtils::get_settings( $attributes );
			$attributes_normalized = BlockUtils::normalize_attributes_for_css( self::CSS_VAR_SETTINGS, $attributes_responsive );
			$vars                  = BlockUtils::generate_css_variables( self::CSS_VAR_SETTINGS, $attributes_normalized, ' --wpbbe-ticker-' );
			ResponsiveBlockUtils::add_style_for_media_query(
				"@media screen and (width <= {$switch_width})",
				"body .{$class_id}.{$class_id}",
				$vars
			);
		}

		return sprintf(
			'<div class="%1$s">
				<div class="wpbbe-ticker-track">
					<div class="wpbbe-ticker-group">
						%2$s
					</div>
					<div class="wpbbe-ticker-group duplicate" aria-hidden="true">
						%2$s
					</div>
				</div>
		</div>',
			esc_attr( implode( ' ', $wrapper_classes ) ),
			$content
		);
	}
}
